﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Framework
{
    public class Const
    {
        /// <summary>
        /// Application en cours
        /// </summary>
        public static string CurrentApplication = AppDomain.CurrentDomain.BaseDirectory;
    }
}